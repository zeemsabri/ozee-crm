/**
 * "Bills" tab — every bill raised against this guest's proposals on this project,
 * flattened into one table so they can see what's been invoiced and what's been paid.
 *
 * Read-only by design: bill creation lives behind the `create_project_bills`
 * permission on the authenticated side, so there is nothing here for a guest to submit.
 */

import { Label } from '../ds';
import { billTone, money, plural, statusLabel, sumByCurrency } from './format';

const GRID = '1.5fr 1.4fr 0.9fr 1fr 0.8fr';

export function BillsTab({ proposals, currency }) {
    const rows = proposals.flatMap((p) =>
        (p.bills || []).map((b) => ({
            ...b,
            scopeName: p.scope === 'project' ? 'Whole project' : p.milestone_name || 'Phase proposal',
            proposalNumber: p.number,
        })),
    );

    // Totals are per-currency: a guest may hold an AUD proposal and a PKR one, and
    // adding those into a single figure would be nonsense.
    const billedText = sumByCurrency(rows, currency);
    const unbilled = proposals
        .filter((p) => p.status === 'Accepted')
        .map((p) => {
            const paid = (p.bills || []).reduce((m, b) => m + Number(b.amount || 0), 0);
            return { amount: Math.max(0, Number(p.amount || 0) - paid), currency: p.currency };
        })
        .filter((r) => r.amount > 0);

    return (
        <section
            style={{
                background: 'var(--primary-background-color)',
                border: '1px solid var(--layout-border-color)',
                borderRadius: 'var(--border-radius-medium)',
                overflow: 'hidden',
            }}
        >
            {rows.length ? (
                <>
                    <div
                        style={{
                            display: 'grid',
                            gridTemplateColumns: GRID,
                            gap: 12,
                            padding: '10px 16px',
                            borderBottom: '1px solid var(--layout-border-color)',
                            font: 'var(--font-text3-medium)',
                            color: 'var(--secondary-text-color)',
                        }}
                    >
                        <span>Invoice</span>
                        <span>Proposal</span>
                        <span style={{ textAlign: 'end' }}>Amount</span>
                        <span>Due</span>
                        <span style={{ textAlign: 'end' }}>Status</span>
                    </div>

                    {rows.map((b) => (
                        <div
                            key={b.id}
                            style={{
                                display: 'grid',
                                gridTemplateColumns: GRID,
                                gap: 12,
                                alignItems: 'center',
                                padding: '10px 16px',
                                borderBottom: '1px solid var(--om-hairline-soft)',
                            }}
                        >
                            <div style={{ minWidth: 0 }}>
                                <div
                                    style={{
                                        font: 'var(--font-text2-medium)',
                                        overflow: 'hidden',
                                        textOverflow: 'ellipsis',
                                        whiteSpace: 'nowrap',
                                    }}
                                >
                                    {b.reference_number || b.number}
                                </div>
                                {b.raised_at ? (
                                    <div
                                        style={{
                                            font: 'var(--font-text3-normal)',
                                            color: 'var(--secondary-text-color)',
                                        }}
                                    >
                                        Raised {b.raised_at}
                                    </div>
                                ) : null}
                            </div>
                            <div style={{ minWidth: 0 }}>
                                <div
                                    style={{
                                        font: 'var(--font-text2-normal)',
                                        overflow: 'hidden',
                                        textOverflow: 'ellipsis',
                                        whiteSpace: 'nowrap',
                                    }}
                                >
                                    {b.scopeName}
                                </div>
                                <div
                                    style={{
                                        font: 'var(--font-text3-normal)',
                                        color: 'var(--secondary-text-color)',
                                    }}
                                >
                                    {b.proposalNumber}
                                </div>
                            </div>
                            <span style={{ textAlign: 'end', font: 'var(--font-text2-medium)' }}>
                                {money(b.amount, b.currency)}
                            </span>
                            <span
                                style={{
                                    font: 'var(--font-text3-normal)',
                                    color: 'var(--secondary-text-color)',
                                    overflow: 'hidden',
                                    textOverflow: 'ellipsis',
                                    whiteSpace: 'nowrap',
                                }}
                            >
                                {b.due_date || '—'}
                            </span>
                            <span style={{ display: 'flex', justifyContent: 'flex-end' }}>
                                <Label
                                    text={statusLabel(b.status)}
                                    color={billTone(b.status)}
                                    kind="line"
                                    size="small"
                                />
                            </span>
                        </div>
                    ))}
                </>
            ) : null}

            <div style={{ padding: '12px 16px', display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '8px 16px' }}>
                <span style={{ font: 'var(--font-text3-normal)', color: 'var(--secondary-text-color)' }}>
                    {rows.length
                        ? `${plural(rows.length, 'bill')} · ${billedText} billed in total`
                        : 'No bills yet — once a proposal is accepted, the accounts team raises the invoice and it appears here.'}
                </span>
                {unbilled.length ? (
                    <span
                        style={{
                            marginInlineStart: 'auto',
                            font: 'var(--font-text3-medium)',
                            color: 'var(--primary-color)',
                        }}
                    >
                        {sumByCurrency(unbilled, currency)} accepted but not yet billed
                    </span>
                ) : null}
            </div>
        </section>
    );
}
