<?php

namespace App\Http\Controllers\Public;

use App\Http\Controllers\Controller;
use App\Models\Project;
use App\Models\User;
use App\Models\UserInteraction;
use App\Services\OtpService;
use App\Services\PortalAccessService;
use App\Services\PortalProfileService;
use App\Services\PortalProjectPresenter;
use App\Services\PortalSessionService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Inertia\Inertia;
use Inertia\Response;

/**
 * The front door of the supplier portal: the link people receive by email.
 *
 * This controller's whole job is to get someone identified. It renders the project
 * brief with a sign-in panel, sends and checks the emailed code, and then hands over to
 * PortalController — which owns every signed-in URL.
 *
 * Once verified, the session token goes into an HttpOnly cookie (see
 * PortalSessionService) rather than staying in the browser's localStorage, which is
 * what allows the portal to have real server-rendered URLs instead of one page
 * switching views client-side.
 */
class PublicProjectController extends Controller
{
    public function __construct(
        private OtpService $otpService,
        private PortalSessionService $portalSession,
        private PortalAccessService $access,
        private PortalProjectPresenter $presenter,
        private PortalProfileService $profiles,
    ) {}

    /**
     * Raw-token form of the share link.
     */
    public function show(Request $request, string $token): Response|RedirectResponse
    {
        return $this->entryPoint($request, $this->resolveProjectByToken($token));
    }

    /**
     * Friendly form of the share link — this is what the invite emails contain.
     */
    public function showPretty(Request $request, string $slug, string $code): Response|RedirectResponse
    {
        return $this->entryPoint($request, $this->resolveProjectByCode($code));
    }

    /**
     * Already identified and allowed in? Go straight to the real project URL. Otherwise
     * show the brief with a sign-in panel.
     */
    private function entryPoint(Request $request, Project $project): Response|RedirectResponse
    {
        $user = $this->portalSession->resolve($request);

        if ($user && $this->access->canAccess($user, $project)) {
            return redirect()->route('portal.projects.show', $project);
        }

        return Inertia::render('React/Portal/Project', [
            'project'        => $this->presenter->project($project, $project->public_share_token),
            // Signed out: no personal data, and the page renders its sign-in panel.
            'account'        => null,
            'proposals'      => [],
            'paymentMethods' => [],
            'branding'       => $this->presenter->branding(),
            'currencies'     => PortalProjectPresenter::CURRENCIES,
        ]);
    }

    private function resolveProjectByToken(string $token): Project
    {
        return Project::query()
            ->where('public_share_token', $token)
            ->where('public_share_enabled', true)
            ->firstOrFail();
    }

    private function resolveProjectByCode(string $code): Project
    {
        // Escape LIKE wildcards: `%` in the URL segment would otherwise match the first
        // enabled project and hand back its full share token in the page props, and
        // character-by-character probing would recover any project's token.
        $escaped = addcslashes($code, '%_\\');

        return Project::query()
            ->where('public_share_enabled', true)
            ->where('public_share_token', 'like', $escaped.'%')
            ->firstOrFail();
    }

    private function findSharedProject(string $token): ?Project
    {
        return Project::where('public_share_token', $token)
            ->where('public_share_enabled', true)
            ->first();
    }

    /**
     * Email a 6-digit code for this project's share link.
     */
    public function sendOtp(Request $request, string $token): JsonResponse
    {
        $validator = Validator::make($request->all(), ['email' => 'required|email|max:255']);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        if (! $this->findSharedProject($token)) {
            return response()->json(['message' => 'This project link is not active.'], 404);
        }

        $this->otpService->generate($request->email, $token);

        return response()->json(['message' => 'Verification code sent to your email.']);
    }

    /**
     * Check the code, start a portal session, and say where to go next.
     *
     * The email is matched against `users`, so someone who already has an account here
     * is recognised as themselves rather than as a new guest — that is what makes the
     * All projects page able to show their team projects too.
     */
    public function verifyOtp(Request $request, string $token): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'otp'   => 'required|string|size:6',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $result = $this->otpService->verify($request->email, $request->otp, $token);

        if (! $result) {
            return response()->json(['message' => 'Invalid or expired verification code.'], 422);
        }

        $project = $this->findSharedProject($token);

        if (! $project) {
            return response()->json(['message' => 'This project link is not active.'], 404);
        }

        $user = User::withTrashed()->find($result['guest_user_id']);

        $this->trackInteraction((int) $user->getKey(), $project->id, 'link_open');

        return response()->json([
            'message'     => 'Verified.',
            'needs_profile' => $result['needs_profile'],
            'account'     => $this->profiles->present($user),
            // Where the browser should go now that a session exists.
            'redirect_to' => route('portal.projects.show', $project),
        ])->withCookie($this->portalSession->cookieFor($result['session_token']));
    }

    private function trackInteraction(int $userId, int $projectId, string $interactionType): void
    {
        UserInteraction::firstOrCreate([
            'user_id'           => $userId,
            'interactable_id'   => $projectId,
            'interactable_type' => Project::class,
            'interaction_type'  => $interactionType,
        ])->touch();
    }
}
