<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Legacy project page
    |--------------------------------------------------------------------------
    |
    | The share links people already have (/projects/public/...) normally render
    | the React portal. Set PORTAL_LEGACY=true to route them to the pre-redesign
    | Vue page instead — a one-line rollback if the new portal misbehaves in
    | front of a client.
    |
    | Only one of the two is ever routed, so there is never a second live entry
    | point into proposal submission. Run `php artisan route:clear` after
    | flipping this: routes are registered from config, so a cached route file
    | has the old choice baked in.
    |
    */

    'legacy' => (bool) env('PORTAL_LEGACY', false),

];
