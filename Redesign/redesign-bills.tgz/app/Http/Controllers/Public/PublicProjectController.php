<?php

namespace App\Http\Controllers\Public;

use App\Enums\BillStatus;
use App\Enums\MilestoneStatus;
use App\Enums\ProjectExpendableStatus;
use App\Http\Controllers\Controller;
use App\Mail\GuestBillSubmittedMail;
use App\Models\Bill;
use App\Models\Milestone;
use App\Models\Project;
use App\Models\ProjectExpendable;
use App\Models\User;
use App\Models\UserInteraction;
use App\Services\BillApprovalFlowService;
use App\Services\CurrencyConversionService;
use App\Services\GuestPaymentMethodService;
use App\Services\OtpService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Inertia\Inertia;
use Inertia\Response;

class PublicProjectController extends Controller
{
    /**
     * Currencies a guest may quote in. Declared once so the validator and the page
     * can't drift apart.
     */
    private const CURRENCIES = ['PKR', 'AUD', 'USD', 'EUR', 'GBP', 'INR'];

    /**
     * Milestone states that are finished one way or another. The public page only ever
     * shows work that is still open, so a guest is never invited to quote for it.
     */
    private const CLOSED_MILESTONE_STATUSES = [
        MilestoneStatus::Approved,
        MilestoneStatus::Rejected,
        MilestoneStatus::Completed,
        MilestoneStatus::Canceled,
        MilestoneStatus::Expired,
    ];

    public function __construct(
        private OtpService $otpService,
        private GuestPaymentMethodService $paymentMethods,
        private BillApprovalFlowService $billApprovalFlow,
        private CurrencyConversionService $currencyConversion,
    ) {}

    /**
     * Render the public project view (no auth required).
     */
    public function show(string $token): Response
    {
        $project = $this->resolveProjectByToken($token);

        return $this->renderProjectPage($project, $token);
    }

    /**
     * Render public project page using a friendly URL structure.
     */
    public function showPretty(string $slug, string $code): Response
    {
        $project = $this->resolveProjectByCode($code);

        return $this->renderProjectPage($project, $project->public_share_token);
    }

    private function renderProjectPage(Project $project, string $token): Response
    {
        $brandingConfig = config('branding');

        $project->load([
            'manager:id,name',
            'admin:id,name',
            'milestones' => function ($q) {
                $q->select('id', 'project_id', 'name', 'description', 'status', 'completion_date')
                    // Public view should only show active/pending work.
                    ->whereNotIn('status', $this->closedMilestoneStatusValues())
                    ->orderBy('completion_date')
                    ->orderBy('created_at');
            },
            'projectDeliverables' => function ($q) {
                $q->select('id', 'project_id', 'milestone_id', 'name', 'description', 'status', 'due_date', 'details')
                    // Keep public deliverables focused on pending work.
                    ->whereNotIn('status', ['completed', 'approved', 'canceled'])
                    ->orderBy('due_date')
                    ->orderBy('created_at');
            },
        ]);

        $milestones = $project->milestones->map(fn ($m) => [
            'id'              => $m->id,
            'name'            => (string) $m->name,
            'description'     => $m->description ? (string) $m->description : null,
            'status'          => $m->status instanceof \BackedEnum ? $m->status->value : (string) $m->status,
            'completion_date' => $m->completion_date?->format('d M Y'),
        ])->values();

        $activeMilestoneIds = $milestones->pluck('id')->all();

        $deliverables = $project->projectDeliverables
            ->filter(fn ($d) => is_null($d->milestone_id) || in_array($d->milestone_id, $activeMilestoneIds, true))
            ->map(function ($d) {
                $checklist = $this->sanitizeChecklist($d->details);

                return [
                    'id'              => $d->id,
                    'milestone_id'    => $d->milestone_id,
                    'name'            => (string) $d->name,
                    'description'     => $d->description ? (string) $d->description : null,
                    'status'          => $d->status instanceof \BackedEnum ? $d->status->value : (string) $d->status,
                    'due_date'        => $d->due_date?->format('d M Y'),
                    'checklist'       => $checklist,
                    // Pre-counted so the page can show phase progress without re-walking
                    // every checklist on each render.
                    'checklist_total' => count($checklist),
                    'checklist_done'  => count(array_filter($checklist, fn ($c) => $c['completed'])),
                ];
            })
            ->values();

        $projectStatus = $project->status instanceof \BackedEnum
            ? $project->status->value
            : (string) $project->status;

        // `projects` has no due-date column, so the project's target completion is the
        // last milestone to land. Uses every milestone, not just the open ones.
        $targetCompletion = $project->milestones()->max('completion_date');

        return Inertia::render('React/Public/ProjectProposals', [
            'project' => [
                'id'                 => $project->id,
                'name'               => $project->name,
                'description'        => $project->description,
                'status'             => $projectStatus,
                'token'              => $token,
                'target_completion'  => $targetCompletion
                    ? \Illuminate\Support\Carbon::parse($targetCompletion)->format('d M Y')
                    : null,
                // Whoever the guest should be talking to about this work.
                'contact'            => $project->manager?->name ?? $project->admin?->name,
                'phase_count'        => $milestones->count(),
                'total_phase_count'  => $project->milestones()->count(),
                'deliverable_count'  => $deliverables->count(),
                'milestones'         => $milestones,
                'deliverables'       => $deliverables,
            ],
            'branding' => [
                'company' => [
                    'name' => $brandingConfig['company']['name'] ?? null,
                    'website' => $brandingConfig['company']['website'] ?? null,
                    'phone' => $brandingConfig['company']['phone'] ?? null,
                    'address' => $brandingConfig['company']['address'] ?? null,
                    'logo_url' => ! empty($brandingConfig['company']['logo_url'])
                        ? asset($brandingConfig['company']['logo_url'])
                        : null,
                ],
                // The signature tagline is stored with a <br> for emails; the page wants
                // one line of plain text.
                'tagline' => isset($brandingConfig['signature']['tagline'])
                    ? trim(preg_replace('/\s+/', ' ', strip_tags((string) $brandingConfig['signature']['tagline'])))
                    : null,
                'support_email' => config('mail.from.address'),
            ],
            'currencies' => self::CURRENCIES,
        ]);
    }

    /**
     * @return array<int, string>
     */
    private function closedMilestoneStatusValues(): array
    {
        return array_map(fn (MilestoneStatus $s) => $s->value, self::CLOSED_MILESTONE_STATUSES);
    }

    private function sanitizeChecklist($details): array
    {
        if (! is_array($details)) {
            return [];
        }

        $items = $details['checklist'] ?? [];

        if (! is_array($items)) {
            return [];
        }

        return collect($items)
            ->map(function ($item) {
                if (! is_array($item)) {
                    return null;
                }

                $name = trim((string) ($item['name'] ?? ''));
                if ($name === '') {
                    return null;
                }

                return [
                    'name' => $name,
                    'completed' => (bool) ($item['completed'] ?? false),
                ];
            })
            ->filter()
            ->values()
            ->all();
    }

    private function resolveProjectByToken(string $token): Project
    {
        return Project::query()
            ->where('public_share_token', $token)
            ->where('public_share_enabled', true)
            ->firstOrFail();
    }

    private function resolveProjectByCode(string $code): Project
    {
        return Project::query()
            ->where('public_share_enabled', true)
            ->where('public_share_token', 'like', $code.'%')
            ->firstOrFail();
    }

    /**
     * Look up the shared project for one of the JSON endpoints.
     * Returns null when the link has been disabled or regenerated since page load.
     */
    private function findSharedProject(string $token): ?Project
    {
        return Project::where('public_share_token', $token)
            ->where('public_share_enabled', true)
            ->first();
    }

    /**
     * Send OTP to the provided email.
     */
    public function sendOtp(Request $request, string $token): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        if (! $this->findSharedProject($token)) {
            return response()->json(['message' => 'This project link is not active.'], 404);
        }

        $this->otpService->generate($request->email, $token);

        return response()->json(['message' => 'Verification code sent to your email.']);
    }

    /**
     * Verify OTP and return a session token.
     */
    public function verifyOtp(Request $request, string $token): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'otp'   => 'required|string|size:6',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $result = $this->otpService->verify($request->email, $request->otp, $token);

        if (! $result) {
            return response()->json(['message' => 'Invalid or expired verification code.'], 422);
        }

        $project = $this->findSharedProject($token);

        if (! $project) {
            return response()->json(['message' => 'This project link is not active.'], 404);
        }

        $guestUser = User::withTrashed()->find($result['guest_user_id']);

        return response()->json([
            'session_token' => $result['session_token'],
            'needs_profile' => $result['needs_profile'],
            'user'            => $this->presentGuest($guestUser),
            'payment_methods' => $this->paymentMethods->maskedList($guestUser),
            'proposals'       => $this->proposalsForGuest($project, (int) $guestUser->id),
            // Retained for the legacy Vue page, which prefills a single form from it.
            'latest_proposal' => $this->latestProposalForGuest($project->id, (int) $guestUser->id),
        ]);
    }

    /**
     * Resolve current verified session details, the guest's proposals and their bills.
     */
    public function session(Request $request, string $token): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'session_token' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $project = $this->findSharedProject($token);

        if (! $project) {
            return response()->json(['message' => 'This project link is not active.'], 404);
        }

        $guestUser = $this->otpService->resolveGuest($request->session_token, $token);

        if (! $guestUser) {
            return response()->json(['message' => 'Session expired. Please verify your email again.'], 401);
        }

        return response()->json([
            'user'            => $this->presentGuest($guestUser),
            'needs_profile'   => $this->guestNeedsProfile($guestUser),
            'payment_methods' => $this->paymentMethods->maskedList($guestUser),
            'proposals'       => $this->proposalsForGuest($project, (int) $guestUser->id),
            'latest_proposal' => $this->latestProposalForGuest($project->id, (int) $guestUser->id),
        ]);
    }

    /**
     * Update the guest user's profile (name + phone).
     */
    public function updateProfile(Request $request, string $token): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'session_token' => 'required|string',
            'name'          => 'required|string|max:255',
            'phone'         => 'required|string|max:30',
            'business_name' => 'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $guestUser = $this->otpService->resolveGuest($request->session_token, $token);

        if (! $guestUser) {
            return response()->json(['message' => 'Session expired. Please verify your email again.'], 401);
        }

        // Merge rather than replace: metadata also carries the guest's saved payment
        // methods, and other parts of the app write their own keys here.
        $metadata = $guestUser->metadata ?? [];
        $metadata['phone'] = $request->phone;

        if ($request->has('business_name')) {
            $businessName = trim((string) $request->input('business_name'));
            $metadata['business_name'] = $businessName !== '' ? $businessName : null;
        }

        $guestUser->update([
            'name'     => $request->name,
            'metadata' => $metadata,
        ]);

        return response()->json([
            'message' => 'Profile saved.',
            'user'    => $this->presentGuest($guestUser->refresh()),
        ]);
    }

    /**
     * Submit or update the guest's proposals.
     *
     * Scope decides how many rows are written:
     *   'milestone'  — one proposal for one phase
     *   'milestones' — one proposal *per* selected phase, each with its own amount,
     *                  sharing the cover letter, payment terms and document
     *   'project'    — one proposal covering the whole project
     *
     * Within a scope, an existing not-yet-accepted proposal from this guest is updated
     * in place rather than duplicated, so re-quoting replaces the pending version. An
     * accepted proposal is never touched.
     */
    public function storeProposal(Request $request, string $token): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'session_token'   => 'required|string',
            'proposal_scope'  => 'required|string|in:milestone,milestones,project',
            'milestone_id'    => 'required_if:proposal_scope,milestone|nullable|integer|exists:milestones,id',
            'milestone_ids'   => 'required_if:proposal_scope,milestones|array|min:1',
            'milestone_ids.*' => 'integer|exists:milestones,id',
            'description'     => 'required|string|min:20|max:5000',
            // A single amount for one phase or the whole project; a map of
            // milestone id => amount when quoting several phases at once.
            'amount'          => 'required_unless:proposal_scope,milestones|nullable|numeric|min:1',
            'amounts'         => 'required_if:proposal_scope,milestones|array',
            'amounts.*'       => 'numeric|min:1',
            'currency'        => 'required|string|in:'.implode(',', self::CURRENCIES),
            'payment_terms'   => 'nullable|string|max:10000',
            'document'        => 'nullable|file|mimes:pdf|max:10240',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $project = $this->findSharedProject($token);

        if (! $project) {
            return response()->json(['message' => 'This project link is not active.'], 404);
        }

        $guestUser = $this->otpService->resolveGuest($request->session_token, $token);

        if (! $guestUser) {
            return response()->json(['message' => 'Session expired. Please verify your email again.'], 401);
        }

        $scope = $request->string('proposal_scope')->toString();

        // Resolve the scope into a list of [morph target, amount] pairs to write.
        $targets = [];

        if ($scope === 'project') {
            $targets[] = ['target' => $project, 'amount' => (float) $request->input('amount')];
        } else {
            $requestedIds = $scope === 'milestones'
                ? array_map('intval', $request->input('milestone_ids', []))
                : [(int) $request->input('milestone_id')];

            // Milestone proposals must belong to the shared project, and must be for
            // work that is still open.
            $milestones = $project->milestones()
                ->whereIn('id', $requestedIds)
                ->whereNotIn('status', $this->closedMilestoneStatusValues())
                ->get()
                ->keyBy('id');

            if ($milestones->count() !== count(array_unique($requestedIds))) {
                return response()->json([
                    'message' => 'One of those phases is no longer open for proposals. Reload the page and try again.',
                ], 422);
            }

            $amounts = $request->input('amounts', []);

            foreach ($requestedIds as $id) {
                $amount = $scope === 'milestones'
                    ? (float) ($amounts[$id] ?? 0)
                    : (float) $request->input('amount');

                if ($amount < 1) {
                    return response()->json([
                        'message' => 'Every phase needs an amount of at least 1.',
                    ], 422);
                }

                $targets[] = ['target' => $milestones[$id], 'amount' => $amount];
            }
        }

        // Upload once and attach the same object to every proposal in the batch.
        $documentAttributes = null;
        if ($request->hasFile('document')) {
            $file = $request->file('document');
            $documentAttributes = [
                'project_id' => $project->id,
                'filename'   => $file->getClientOriginalName(),
                'mime_type'  => $file->getMimeType(),
                'file_size'  => $file->getSize(),
                'path'       => Storage::disk('gcs')->putFile('proposals', $file),
            ];
        }

        // Spatie's activity log resolves the causer from the authenticated user, and a
        // guest has no session. Borrow the identity for the whole batch so the log
        // credits them, then put things back exactly as they were.
        $originalUser = auth()->user();
        auth()->setUser($guestUser);

        try {
            DB::transaction(function () use ($targets, $project, $guestUser, $request, $documentAttributes) {
                foreach ($targets as ['target' => $target, 'amount' => $amount]) {
                    $expendable = $this->upsertProposal(
                        project: $project,
                        guestUser: $guestUser,
                        target: $target,
                        amount: $amount,
                        description: (string) $request->input('description'),
                        currency: (string) $request->input('currency'),
                        paymentTerms: $request->input('payment_terms'),
                    );

                    if ($documentAttributes) {
                        $expendable->files()->create($documentAttributes);
                    }
                }
            });
        } finally {
            if ($originalUser) {
                auth()->setUser($originalUser);
            } else {
                // setUser() never touched the session, so forgetUser() is the symmetric
                // undo. logout() would cycle the guest's remember_token and dispatch a
                // Logout event — a real problem when the guest email also has an app
                // account with "remember me" active.
                auth()->forgetUser();
            }
        }

        $this->trackInteraction($guestUser->id, $project->id, 'proposal_submitted');

        $count = count($targets);

        return response()->json([
            'message' => $count > 1
                ? "Your {$count} proposals have been submitted — one per phase. We'll review them and get back to you."
                : 'Your proposal has been submitted successfully. We will review it and get back to you.',
            'proposals' => $this->proposalsForGuest($project, (int) $guestUser->id),
        ]);
    }

    /**
     * Create or update this guest's proposal for one morph target (a Milestone, or the
     * Project itself for a whole-project quote).
     */
    private function upsertProposal(
        Project $project,
        User $guestUser,
        Project|Milestone $target,
        float $amount,
        string $description,
        string $currency,
        ?string $paymentTerms,
    ): ProjectExpendable {
        $isMilestone = $target instanceof Milestone;

        $expendable = ProjectExpendable::query()
            ->where('project_id', $project->id)
            ->where('user_id', $guestUser->id)
            ->where('expendable_type', $isMilestone ? Milestone::class : Project::class)
            ->where('expendable_id', $target->id)
            // Only a proposal still awaiting a decision may be replaced in place.
            // Accepted is a commitment, Completed has been billed and paid, Shortlisted
            // is under active consideration, and Rejected is a record of a decision —
            // re-quoting any of those must create a new row, not rewrite history.
            ->where('status', ProjectExpendableStatus::PendingApproval->value)
            ->latest()
            ->first();

        $attributes = [
            'name'            => $isMilestone
                ? $target->name.' — proposal from '.($guestUser->name ?: $guestUser->email)
                : 'Whole project proposal from '.($guestUser->name ?: $guestUser->email),
            'description'     => $description,
            'currency'        => $currency,
            'amount'          => $amount,
            'payment_terms'   => $paymentTerms,
            'expendable_id'   => $target->id,
            'expendable_type' => $isMilestone ? Milestone::class : Project::class,
            'status'          => ProjectExpendableStatus::PendingApproval->value,
        ];

        if ($expendable) {
            // Only re-baseline the balance while nothing has been billed against it.
            if ($expendable->bills()->doesntExist()) {
                $attributes['balance'] = $amount;
            }

            $expendable->update($attributes);

            return $expendable;
        }

        return ProjectExpendable::create($attributes + [
            'project_id' => $project->id,
            'user_id'    => $guestUser->id,
            'balance'    => $amount,
        ]);
    }

    /**
     * Track a verified guest opening the public project page or clicking the share link.
     */
    public function track(Request $request, string $token): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'session_token' => 'required|string',
            // 'proposal_submitted' is also written server-side by storeProposal; it is
            // accepted here so the page's own tracking call doesn't 422.
            'event'         => 'required|string|in:link_open,page_view,proposal_submitted',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $project = $this->findSharedProject($token);

        if (! $project) {
            return response()->json(['message' => 'This project link is not active.'], 404);
        }

        $guestUser = $this->otpService->resolveGuest($request->session_token, $token);

        if (! $guestUser) {
            return response()->json(['message' => 'Session expired. Please verify your email again.'], 401);
        }

        $this->trackInteraction($guestUser->id, $project->id, $request->event);

        return response()->json(['message' => 'Tracked.']);
    }

    private function trackInteraction(int $userId, int $projectId, string $interactionType): void
    {
        // `updated_at` is not fillable on UserInteraction, so passing it as an update
        // attribute is silently dropped and the model is never dirty — meaning a repeat
        // event would leave the timestamp frozen at first contact. touch() is explicit.
        UserInteraction::firstOrCreate([
            'user_id'           => $userId,
            'interactable_id'   => $projectId,
            'interactable_type' => Project::class,
            'interaction_type'  => $interactionType,
        ])->touch();
    }

    /**
     * Save a payout method for this guest. Stored against their user record so it can be
     * picked on every future bill instead of re-typed — see GuestPaymentMethodService
     * for the storage and encryption details.
     */
    public function storePaymentMethod(Request $request, string $token): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'session_token' => 'required|string',
            'type'          => 'required|string|in:'.implode(',', GuestPaymentMethodService::TYPES),
            'label'         => 'required|string|max:100',
            'country'       => 'nullable|string|max:100',
            'currency'      => 'nullable|string|in:'.implode(',', self::CURRENCIES),
            'fields'        => 'required|array',
            'fields.*'      => 'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $guestUser = $this->resolveGuestOrNull($token, $request->input('session_token'));

        if (! $guestUser) {
            return response()->json(['message' => 'Session expired. Please verify your email again.'], 401);
        }

        try {
            [$methods] = $this->paymentMethods->add($guestUser, $validator->validated());
        } catch (\InvalidArgumentException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }

        return response()->json([
            'message'         => 'Payment method saved.',
            'payment_methods' => $methods,
        ]);
    }

    public function destroyPaymentMethod(Request $request, string $token, string $methodId): JsonResponse
    {
        $guestUser = $this->resolveGuestOrNull($token, $request->input('session_token'));

        if (! $guestUser) {
            return response()->json(['message' => 'Session expired. Please verify your email again.'], 401);
        }

        return response()->json([
            'message'         => 'Payment method removed.',
            'payment_methods' => $this->paymentMethods->remove($guestUser, $methodId),
        ]);
    }

    public function defaultPaymentMethod(Request $request, string $token, string $methodId): JsonResponse
    {
        $guestUser = $this->resolveGuestOrNull($token, $request->input('session_token'));

        if (! $guestUser) {
            return response()->json(['message' => 'Session expired. Please verify your email again.'], 401);
        }

        if (! $this->paymentMethods->find($guestUser, $methodId)) {
            return response()->json(['message' => 'That payment method no longer exists.'], 422);
        }

        return response()->json([
            'message'         => 'Default payment method updated.',
            'payment_methods' => $this->paymentMethods->makeDefault($guestUser, $methodId),
        ]);
    }

    /**
     * Upload a bill against one of the guest's accepted proposals.
     *
     * The guest supplies only what they can know: their invoice, its number, the amount
     * and where to be paid. The Xero account code, tax type and transaction type are
     * left null for the accounts team to fill in on the admin bills screen — the bill
     * cannot be approved until at least the account code is set
     * (BillController::performFinalBillApproval enforces that).
     *
     * Mirrors the guards in BillController::store: the contract must belong to this
     * project and this guest, must be Accepted, and the bill must fit inside what is
     * left of the contract once pending bills are taken into account.
     */
    public function storeBill(Request $request, string $token): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'session_token'     => 'required|string',
            'proposal_id'       => 'required|integer',
            'payment_method_id' => 'required|string',
            'reference_number'  => 'required|string|max:255',
            'amount'            => 'required|numeric|min:0.01',
            'currency'          => 'required|string|in:'.implode(',', self::CURRENCIES),
            'due_date'          => 'nullable|date|after_or_equal:today',
            // The invoice itself is the point of the exercise, so unlike the admin path
            // it is required here.
            'document'          => 'required|file|mimes:pdf|max:10240',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $project = $this->findSharedProject($token);

        if (! $project) {
            return response()->json(['message' => 'This project link is not active.'], 404);
        }

        $guestUser = $this->otpService->resolveGuest($request->session_token, $token);

        if (! $guestUser) {
            return response()->json(['message' => 'Session expired. Please verify your email again.'], 401);
        }

        $expendable = ProjectExpendable::query()
            ->where('id', $request->integer('proposal_id'))
            ->where('project_id', $project->id)
            ->where('user_id', $guestUser->id)
            ->first();

        if (! $expendable) {
            return response()->json(['message' => 'That proposal is not one of yours.'], 422);
        }

        $status = $expendable->status instanceof \BackedEnum
            ? $expendable->status->value
            : (string) $expendable->status;

        if ($status !== ProjectExpendableStatus::Accepted->value) {
            return response()->json([
                'message' => 'You can only bill a proposal once it has been accepted.',
                'errors'  => ['proposal_id' => ['This proposal has not been accepted yet.']],
            ], 422);
        }

        $method = $this->paymentMethods->find($guestUser, (string) $request->input('payment_method_id'));

        if (! $method) {
            return response()->json([
                'message' => 'Choose a payment method to be paid to.',
                'errors'  => ['payment_method_id' => ['That payment method no longer exists.']],
            ], 422);
        }

        $remaining = $this->billableRemaining($expendable);
        $amount = (float) $request->input('amount');

        try {
            $amountInContractCurrency = $this->currencyConversion->convert(
                $amount,
                (string) $request->input('currency'),
                $expendable->currency ?? 'AUD',
            );
        } catch (\Throwable $e) {
            return response()->json([
                'message' => 'We could not convert that amount to the contract currency. Bill in '.($expendable->currency ?? 'AUD').' instead.',
                'errors'  => ['currency' => [$e->getMessage()]],
            ], 422);
        }

        if (round($amountInContractCurrency, 2) > round($remaining, 2)) {
            return response()->json([
                'message' => 'That is more than is left to bill on this proposal.',
                'errors'  => ['amount' => [
                    'You have '.number_format($remaining, 2).' '.($expendable->currency ?? 'AUD').' left to bill, once bills already awaiting approval are counted.',
                ]],
            ], 422);
        }

        // Upload before opening the transaction: a storage failure then aborts without
        // leaving a bill behind, which is the opposite of the admin path's behaviour.
        $file = $request->file('document');
        try {
            $objectPath = Storage::disk('gcs')->putFile('bills', $file);
        } catch (\Throwable $e) {
            Log::error('Guest bill upload failed to store document: '.$e->getMessage());

            return response()->json(['message' => 'We could not store that file. Try again in a moment.'], 500);
        }

        $paymentDetail = $this->paymentMethods->toBillPaymentDetail($method);

        $bill = DB::transaction(function () use ($project, $guestUser, $expendable, $request, $amount, $paymentDetail, $file, $objectPath) {
            $bill = Bill::create([
                'project_id'            => $project->id,
                'contractor_id'         => $guestUser->id,
                'project_expendable_id' => $expendable->id,
                // Left for the accounts team — a supplier has no way to know these.
                'transaction_type_id'   => null,
                'xero_account_code'     => null,
                'xero_tax_type'         => null,
                'reference_number'      => $request->input('reference_number'),
                'due_date'              => $request->input('due_date'),
                'currency'              => $request->input('currency'),
                'amount'                => $amount,
                'status'                => BillStatus::PendingApproval,
            ]);

            $bill->paymentDetail()->create([
                'contractor_id'  => $guestUser->id,
                'payment_method' => $paymentDetail['payment_method'],
                'details'        => $paymentDetail['details'],
            ]);

            $bill->files()->create([
                'project_id' => $project->id,
                'filename'   => $file->getClientOriginalName(),
                'mime_type'  => $file->getMimeType(),
                'file_size'  => $file->getSize(),
                'path'       => $objectPath,
            ]);

            return $bill;
        });

        // Same approval flow an internally created bill enters.
        $this->billApprovalFlow->initialize($bill, $project->id);

        $this->notifyAccountsOfGuestBill($bill);

        return response()->json([
            'message'   => 'Bill uploaded. The accounts team has been notified and will review it.',
            'proposals' => $this->proposalsForGuest($project, (int) $guestUser->id),
        ]);
    }

    /**
     * What is still billable on an accepted contract, in the contract's own currency.
     *
     * `balance` is already reduced for approved bills, so only bills still awaiting
     * approval need subtracting — the same arithmetic BillController::store performs.
     */
    private function billableRemaining(ProjectExpendable $expendable): float
    {
        $contractCurrency = $expendable->currency ?? 'AUD';

        $pending = $expendable->bills()
            ->where('status', BillStatus::PendingApproval)
            ->get()
            ->reduce(function (float $carry, Bill $bill) use ($contractCurrency) {
                try {
                    return $carry + $this->currencyConversion->convert(
                        (float) $bill->amount,
                        $bill->currency ?? 'AUD',
                        $contractCurrency,
                    );
                } catch (\Throwable $e) {
                    // Matches the admin path, which also ignores conversion failures for
                    // already-pending bills rather than blocking a new one.
                    return $carry;
                }
            }, 0.0);

        return max(0, (float) $expendable->balance - $pending);
    }

    private function notifyAccountsOfGuestBill(Bill $bill): void
    {
        $recipient = config('mail.mailers.smtp.username') ?: config('mail.from.address');

        if (! $recipient || ! filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
            return;
        }

        try {
            Mail::to($recipient)->queue(new GuestBillSubmittedMail($bill));
        } catch (\Throwable $e) {
            // A mail failure must never lose the guest their upload.
            Log::error('Failed to queue guest bill notification: '.$e->getMessage());
        }
    }

    private function resolveGuestOrNull(string $token, ?string $sessionToken): ?User
    {
        if (! $sessionToken || ! $this->findSharedProject($token)) {
            return null;
        }

        return $this->otpService->resolveGuest($sessionToken, $token);
    }

    /**
     * @return array{name: string, email: string, phone: string}
     */
    private function presentGuest(User $guestUser): array
    {
        return [
            'name'          => $guestUser->name ?? '',
            'email'         => $guestUser->email,
            'phone'         => $guestUser->metadata['phone'] ?? '',
            'business_name' => $guestUser->metadata['business_name'] ?? '',
        ];
    }

    private function guestNeedsProfile(User $guestUser): bool
    {
        return empty($guestUser->name) || empty($guestUser->metadata['phone'] ?? null);
    }

    /**
     * Every proposal this guest has on this project, newest first, each with the bills
     * the accounts team has raised against it.
     *
     * @return array<int, array<string, mixed>>
     */
    private function proposalsForGuest(Project $project, int $guestUserId): array
    {
        /** @var Collection<int, ProjectExpendable> $proposals */
        $proposals = ProjectExpendable::query()
            ->where('project_id', $project->id)
            ->where('user_id', $guestUserId)
            ->with([
                'bills' => fn ($q) => $q->with('transactions')->orderBy('created_at'),
                'files' => fn ($q) => $q->latest(),
            ])
            ->latest()
            ->get();

        // One query for the milestone names rather than a morph load per row.
        $milestoneNames = $project->milestones()
            ->whereIn('id', $proposals
                ->where('expendable_type', Milestone::class)
                ->pluck('expendable_id')
                ->filter()
                ->all())
            ->pluck('name', 'id');

        return $proposals->map(function (ProjectExpendable $p) use ($milestoneNames) {
            $isMilestone = $p->expendable_type === Milestone::class;
            $status = $p->status instanceof \BackedEnum ? $p->status->value : (string) $p->status;
            $document = $p->files->first();

            return [
                'id'             => $p->id,
                'number'         => $p->expendable_number,
                'scope'          => $isMilestone ? 'milestone' : 'project',
                'milestone_id'   => $isMilestone ? (int) $p->expendable_id : null,
                'milestone_name' => $isMilestone ? ($milestoneNames[$p->expendable_id] ?? null) : null,
                'description'    => $p->description,
                'amount'         => (float) $p->amount,
                'currency'       => $p->currency,
                'payment_terms'  => $p->payment_terms,
                'status'         => $status,
                // Mirrors the upsert rule above: anything past 'pending' is a decision
                // the guest must not be able to silently overwrite.
                'can_edit'       => $status === ProjectExpendableStatus::PendingApproval->value,
                'submitted_at'   => $p->created_at?->format('d M Y'),
                'updated_at'     => $p->updated_at?->format('d M Y'),
                // Billing is only open on an accepted contract with room left in it.
                'can_bill'       => $status === ProjectExpendableStatus::Accepted->value
                    && $this->billableRemaining($p) > 0,
                'billable_remaining' => $status === ProjectExpendableStatus::Accepted->value
                    ? round($this->billableRemaining($p), 2)
                    : 0,
                // Name only: guest file downloads would need a signed public route,
                // which doesn't exist yet.
                'document'       => $document ? ['name' => $document->filename, 'url' => null] : null,
                'bills'          => $p->bills->map(function (Bill $bill) {
                    // Payment progress comes from the bank transactions the accounts
                    // team links to the bill, the same source the admin transactions
                    // screen reads. `paid_amount` handles cross-currency payments.
                    $paid = (float) $bill->paid_amount;
                    $lastPaidAt = $bill->transactions
                        ->where('is_paid', true)
                        ->pluck('payment_date')
                        ->filter()
                        ->max();

                    return [
                        'id'               => $bill->id,
                        'number'           => $bill->bill_number,
                        'reference_number' => $bill->reference_number,
                        'amount'           => (float) $bill->amount,
                        'currency'         => $bill->currency,
                        'status'           => $bill->status instanceof \BackedEnum
                            ? $bill->status->value
                            : (string) $bill->status,
                        'due_date'         => $bill->due_date?->format('d M Y'),
                        'raised_at'        => $bill->created_at?->format('d M Y'),
                        'paid_amount'      => round($paid, 2),
                        'remaining_amount' => round(max(0, (float) $bill->amount - $paid), 2),
                        'last_paid_at'     => $lastPaidAt
                            ? \Illuminate\Support\Carbon::parse($lastPaidAt)->format('d M Y')
                            : null,
                    ];
                })->values()->all(),
            ];
        })->values()->all();
    }

    private function latestProposalForGuest(int $projectId, int $guestUserId): ?array
    {
        $proposal = ProjectExpendable::query()
            ->where('project_id', $projectId)
            ->where('user_id', $guestUserId)
            // Do not reuse approved proposals as prefill; users should submit a fresh one.
            ->where('status', '!=', ProjectExpendableStatus::Accepted->value)
            ->latest()
            ->first();

        if (! $proposal) {
            return null;
        }

        $isMilestoneProposal = $proposal->expendable_type === Milestone::class;

        return [
            'proposal_scope' => $isMilestoneProposal ? 'milestone' : 'project',
            'milestone_id'   => $isMilestoneProposal ? $proposal->expendable_id : null,
            'description'    => $proposal->description,
            'amount'         => $proposal->amount,
            'currency'       => $proposal->currency,
            'payment_terms'  => $proposal->payment_terms,
        ];
    }
}
